<?php
print_r($_COOKIE);

echo $_COOKIE['product_name'];
echo $_COOKIE['product_price'];

?>

<br>
<a href="delete_cookie.php">DELETE Cookie</a>