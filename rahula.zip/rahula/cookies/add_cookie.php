<?php
setcookie("product_name","Tshirt",time()+20,"/");// '/' for across domain .
setcookie("product_price","2000",time()+20,"/");
?>

<br>
<a href="show_cookie.php">SHOW Cookie</a>