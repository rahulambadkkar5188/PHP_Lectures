<?php
$res = mysqli_connect("localhost","root","","infi_php_crud");

// echo $sql;
//$uid = $_POST['id'];

$email = $_POST["email"];
// echo $email;
$password = $_POST["pwd"];
$id = $_POST["id"];


$sql = "UPDATE users SET emailid='$email',password = '$password' where id = '$id'";
// echo $sql;
$query = mysqli_query($res,$sql) or die(mysqli_error($res));


// print_r($fans);

header("location:showdata.php");

?>
