<?php

$uid = $_GET['userid'];

$email = $_POST["email"];
// echo $email;
$password = $_POST["pwd"];


$res = mysqli_connect("localhost","root","","infi_php_crud");
$sql = "DELETE FROM users WHERE id = '$uid'";
// echo $sql;
$query = mysqli_query($res,$sql) or die(mysqli_error($res));

//print_r($query);

header("location:showdata.php");

?>
