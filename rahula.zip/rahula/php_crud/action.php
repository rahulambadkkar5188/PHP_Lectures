<?php
$res = mysqli_connect("localhost","root","","infi_php_crud");

//print_r($res);

// print_r($_POST);

$email = $_POST["email"];
// echo $email;
$password = $_POST["pwd"];

$sql = "INSERT INTO users (emailid,password) VALUES('$email','$password')";

//echo $sql;

$query = mysqli_query($res,$sql) or die(mysqli_error($res));

var_dump($query);

$ans = mysqli_close($res);

var_dump($ans);

header("location:showdata.php");
?>