
<?php
//print_r($_GET);
//print_r($_REQUEST);


$uid = $_GET['userid'];
$res = mysqli_connect("localhost","root","","infi_php_crud");
$sql = "SELECT * FROM users WHERE id='$uid'";
// echo $sql;
$query = mysqli_query($res,$sql) or die(mysqli_error($res));

//print_r($query);

$fans = $query->fetch_object();
print_r($fans);

?>


<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Vertical (basic) Form</h2>
  <form action="update_page.php" method="post">
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control" id="email" name="email" placeholder="Enter email" value="<?php echo $fans->emailid ?>";
    </div>
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" id="pwd" name="pwd" placeholder="Enter password" value="<?php echo $fans->password ?>">
    </div>

    <div class="form-group">
      <label for="id">Password:</label>
      <input type="hidden" class="form-control"  name="id" value="<?php echo $fans->id ?>">
    </div>
    
    <button type="submit" class="btn btn-default">Submit</button>
  </form>
</div>

</body> 
</html>