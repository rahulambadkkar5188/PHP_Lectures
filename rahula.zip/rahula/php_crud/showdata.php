<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<?php
$res = mysqli_connect("localhost","root","","infi_php_crud");
$sql = "SELECT * FROM users";
// echo $sql;
$query = mysqli_query($res,$sql) or die(mysqli_error($res));

//print_r($query);

echo "<table class='table'>";

if($query->num_rows > 0)
{
	while($response = $query -> fetch_object())
	{
		//print_r($response);

		echo "<tr>";
			echo "<td>";
				echo $response->id;
			echo "</td>";

			echo "<td>";
				echo $response->emailid;
			echo "</td>";

			echo "<td>";
				echo $response->password;
			echo "</td>";

			echo "<td>";
				echo "<a class='btn btn-info' href='edit.php?userid=".$response->id."'>EDIT</a>";
			echo "</td>";

			echo "<td>";
				echo "<a class='btn btn-danger' href='delete.php?userid=".$response->id."'>DELETE</a>";
			echo "</td>";
		echo "</tr>";
	}
}
echo "</table>";
?>