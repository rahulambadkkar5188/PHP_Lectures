 <?php
	session_start();
	session_regenerate_id(true);// Regenerate Session id after destroying session.
	unset($_SESSION['name']);
	unset($_SESSION['age']);

	session_destroy();
?>

<br><a href="show_session.php">SHOW Session</a>