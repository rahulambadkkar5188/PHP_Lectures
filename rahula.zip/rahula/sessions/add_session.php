<?php
session_start();

echo session_id();

$_SESSION['name'] = "Ajay";
$_SESSION['age'] = 20;
?>

<br>
<a href="show_session.php">SHOW Session</a>