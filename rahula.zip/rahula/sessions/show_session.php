<?php

session_start();

echo session_id();

print_r($_SESSION);
?>

<br>
<a href="delete_session.php">DELETE Session</a>