<?php

//$file1 = $_FILES['file1']['name'];
print_r($_POST);

echo "<pre>";
	print_r($_FILES);
echo "</pre>";

$tmp = $_FILES['x3']['tmp_name'];
$dest = "uploads/".time().$_FILES['x3']['name'];

$ans = move_uploaded_file($tmp, $dest);

var_dump($ans);

?>