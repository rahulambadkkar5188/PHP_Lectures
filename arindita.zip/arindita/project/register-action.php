<?php
	//db connection
	require_once 'connection.php';
	//print_r($_POST);

	//form validaion
	if(empty($_POST['username'])){
		echo "Please enter username";
	}
	else if(empty($_POST['usermobile'])){
		echo "Please enter mobile";
	}
	else if(empty($_POST['useremail'])){
		echo "Please enter emailid";
	}
	else if(empty($_POST['userpass'])){
		echo "Please enter password";
	}
	else if($_POST['userpass']!=$_POST['usercpass']){
		echo "Please enter confirm password";
	}
	else{
		//echo "ok";

		//textbox data store
		$name = $_POST['username'];
		$mobile = $_POST['usermobile'];
		$email = $_POST['useremail'];
		$password = sha1($_POST['userpass']);

		//query prepare
		$str = "insert into login (name,mobile,email,password,status) values('$name','$mobile','$email','password',0)";

		//echo $str;

		//query execution
		$result = mysqli_query($conn,$str) or die(mysqli_error($conn));

		//var_dump(result);

		if($result){
			echo "user added";
		}

	}
?>