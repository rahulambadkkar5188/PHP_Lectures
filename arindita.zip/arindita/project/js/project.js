//alert("testing files");
$(document).ready(function(){
	//alert("jquery test");
	$(".btn-register").click(function(){
	//	alert("click test");
	data1=$("#name").val();
	data2=$("#mobile").val();
	data3=$("#email").val();
	data4=$("#password").val();
	data5=$("#cpassword").val();
	//alert(data1)
	str="username="+data1+"&usermobile="+data2+"&useremail="+data3+"&userpass="+data4+"$usercpass="+data5
	$.post("register-action.php",str,function(res){
		//console.log(res)
		$(".register_msg").html(res)
	})

	})
})

////////////////
$(".btn-login").click(function(){
data1=$("#log_email").val();
	data2=$("#log_password").val();
	//alert(data1)
	str="useremail="+data1+"&userpass="+data2
	$.post("login-action.php",str,function(res){
		//console.log(res)
		$(".login_msg").html(res)
	})

	})
///////////////////////