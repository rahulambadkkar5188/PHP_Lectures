<?php 
mysqli_close($conn);
 ?>