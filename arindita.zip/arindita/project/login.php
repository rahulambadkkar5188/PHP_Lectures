<?php
require_once 'header.php';
?>
<section id="form"><!--form-->
		<div class="container">
			<div class="row">
				<div class="col-sm-4 col-sm-offset-1">
					<div class="login-form"><!--login form-->
						<h2>Login to your account</h2>
						<form>
							<input type="text" id="log_email" placeholder="Email Adrress">
							<input type="text" id="log_password" placeholder="password">
							<button type="button" class="btn btn-default btn-login">login</button>
						</form>
						<div class="login_msg"></div>
					</div><!--/login form-->
				</div>
				<div class="col-sm-1">
					<h2 class="or">OR</h2>
				</div>
				<div class="col-sm-4">
					<div class="signup-form"><!--sign up form-->
						<h2>New User Signup!</h2>
						<form>
							<input type="text" id="name" placeholder="person name">
							<input type="text" id="mobile" placeholder="person mobile">
							<input type="text" id="email" placeholder="Email address">
							<input type="text" id="password" placeholder="password">
							<input type="text" id="cpassword" placeholder="confirm-password">
							<button type="button" class="btn btn-default btn-register">register</button>
						</form>
						<div class="register_msg"></div>
					</div><!--/sign up form-->
				</div>
			</div>
		</div>
	</section>
<?php
require_once 'footer.php';
?>