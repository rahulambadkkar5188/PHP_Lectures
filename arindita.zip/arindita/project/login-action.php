<?php
	require_once 'connection.php';
	print_r($_POST);

	if(empty($_POST['log_email'])){
		echo "emailid invalid";

	}
	else if(empty($_POST['log_password'])){
		echo "password invalid";
	}
	else{
		//echo "OK";

		$email = $_POST['log_email'];
		//echo $email;
		$password = sha1($_POST['log_password']);
		//echo $password;
		$str = "select * from login where emailid='$email'";
		//echo $str;

		$result = mysql_query($conn,$str) or die(mysql_error($conn));

		//print_r($result);

		if($result->num_rows == 0){
			echo "given emailid does not exist";
		}
		else{
			//echo "OK";
			$ans = mysqli_fetch_assoc($result);
			//print_r($ans);
			$dbpass = $ans['password'];
			//echo $dbpass;

			if($dbpass == $password){
				echo "auth done";
			}
			else{
				echo "password mismatch for given emailid";
			}
		}
	}
?>