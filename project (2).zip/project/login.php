<?php  
	require_once 'header.php';
?>

<section id="form"><!--form-->
		<div class="container">
			<div class="row">
				<div class="col-sm-4 col-sm-offset-1">
					<div class="login-form"><!--login form-->
						<h2>Login to your account</h2>
						<form id="login_form">
							
							<input type="text" name="log_email" placeholder="Email Address">
							<input type="text" name="log_password" placeholder="Password">
							
							
							<button type="button" class="btn btn-default btn-login">Login</button>
						</form>
						<div class="login_msg"></div>
					</div><!--/login form-->
				</div>
				<div class="col-sm-1">
					<h2 class="or">OR</h2>
				</div>
				<div class="col-sm-4">
					<div class="signup-form"><!--sign up form-->
						<h2>New User Signup!</h2>
						<!-- <form>
							
							<input type="text" id="name" placeholder="Person Name">
							<input type="text" id="mobile" placeholder="Person Mobile">
							<input type="text" id="email" placeholder="Email Address">
							<input type="text" id="password" placeholder="Password">
							<input type="text" id="cpassword" placeholder="Confirm Password">
							
							<button type="button" class="btn btn-default btn-register">Register</button>
						</form> -->

						<form id="register_form">
							
							<input type="text" name="username" placeholder="Person Name">
							<input type="text" name="usermobile" placeholder="Person Mobile">
							<input type="text" name="useremail" placeholder="Email Address">
							<input type="text" name="userpass" placeholder="Password">
							<input type="text" name="usercpass" placeholder="Confirm Password">
							
							<button type="button" class="btn btn-default btn-register">Register</button>
						</form>
						<div class="register_msg"></div>
					</div><!--/sign up form-->
				</div>
			</div>
		</div>
	</section>

<?php  
	require_once 'footer.php';
?>