// alert("TESTING FILE");
$(document).ready(function(){
	// alert("JQUERY TEST");
	/********* METHOD 1 ************/
		// $(".btn-register").click(function(){
		// 	// alert("CLICK TEST")
		// 	data1=$("#name").val();
		// 	data2=$("#mobile").val();
		// 	data3=$("#email").val();
		// 	data4=$("#password").val();
		// 	data5=$("#cpassword").val();
		// 	// alert(data1)

		// 	str = "username="+data1+"&usermobile="+data2+"&useremail="+data3+"&userpass="+data4+"&usercpass="+data5
		// 	$.post("register-action.php",str,function(res){
		// 		// console.log(res)
		// 		$(".register_msg").html(res)
		// 	})
		// })
	/********* METHOD 1 ************/
	$(".btn-register").click(function(){
		str = $("#register_form").serialize();
		// console.log(str);
		$.post("register-action.php",str,function(res){
			// console.log(res)
			$(".register_msg").html(res)
		})
	})
	///////////////////////
	$(".btn-login").click(function(){
		// alert("CLICK TEST")
		str = $("#login_form").serialize();
		$.post("login-action.php",str,function(res){
			// console.log(res)
			$(".login_msg").html(res)
		})
	})
	/////////////////////
})