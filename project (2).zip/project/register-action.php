<?php  
	//db connection
	require_once 'connection.php';
	// print_r($_POST);

	//form validation
	if(empty($_POST['username'])){
		echo "Please Enter Username";
	}
	else if(empty($_POST['usermobile'])){
		echo "Please Enter Mobile";
	}
	else if(empty($_POST['useremail'])){
		echo "Please Enter Emailid";
	}
	else if(empty($_POST['userpass'])){
		echo "Please Enter Password";
	}
	else if($_POST['userpass']!=$_POST['usercpass']){
		echo "Please Enter Confirm Password";
	}
	else{
		// echo "ok";

		//textbox data store
		$name = $_POST['username'];
		$mobile = $_POST['usermobile'];
		$email = $_POST['useremail'];
		$password = sha1($_POST['userpass']);

		//query prepare
		$str = "insert into login (name,mobile,emailid,password,status) values ('$name','$mobile','$email','$password',0)";

		// echo $str;

		//query execution
		$result = mysqli_query($conn,$str) or die(mysqli_error($conn));

		// var_dump($result);

		if($result){
			echo "User added";
		}
	}
?>